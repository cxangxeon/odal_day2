// utils/foodService.js
import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

const FOOD_SERVICE_KEY = process.env.BUSAN_FOOD_SERVICE_KEY;
const FOODIE_SERVICE_KEY = process.env.BUSAN_FOODIE_SERVICE_KEY;

// 기본 엔드포인트 (HTTP; 필요 시 HTTPS로 변경)
const FOOD_SERVICE_URL = 'http://apis.data.go.kr/6260000/FoodService/getFoodKr';
const FOODIE_SERVICE_URL = 'http://apis.data.go.kr/6260000/FoodieService/getFoodieKr';

/**
 * 주변 맛집 호출: fetchNearbyFoodService(x, y, radius)
 * 공공데이터 API에 직접 위도/경도를 전달하는 파라미터가 없는 경우가 많음.
 * 따라서 모든 맛집 리스트를 가져와서 클라이언트 단에서 필터링하거나,
 * API 문서에 좌표 검색 기능이 있으면 해당 파라미터 사용.
 *
 * 여기서는 예시로 전체 리스트 중 좌표 차이를 계산하여 반경 내 필터링.
 * - pageNo=1, numOfRows 크게 설정하여 충분한 결과를 받아온 후 클라이언트 필터링 권장.
 *
 * 주의: 전체 데이터를 매번 가져오는 것은 비효율. 실제론 서버 사이드에 인메모리 캐싱,
 * 혹은 주기적으로 전체 데이터를 가져와 로컬 DB에 저장 후 검색 시 DB 쿼리로 처리하는 방식을 추천.
 */
export async function fetchNearbyFoodService(x, y, radius) {
  // 1) API 호출: pageNo=1, numOfRows=1000 (최대 허용치 확인 필요)
  //    resultType=json
  const url = new URL(FOOD_SERVICE_URL);
  url.searchParams.append('ServiceKey', FOOD_SERVICE_KEY);
  url.searchParams.append('pageNo', '1');
  url.searchParams.append('numOfRows', '1000');
  url.searchParams.append('resultType', 'json');

  const res = await fetch(url.toString());
  if (!res.ok) {
    throw new Error(`부산맛집정보 API 오류: ${res.status}`);
  }
  const data = await res.json();
  const items = data.response?.body?.items?.item || []; // API 응답 구조에 맞게 접근
  // items[].RSTR_LA (위도), RSTR_LO (경도) 등의 필드 사용
  if (radius != null) {
    // 반경(m) 내 필터링
    return items.filter(item => {
      if (!item.RSTR_LA || !item.RSTR_LO) return false;
      const lat = parseFloat(item.RSTR_LA);
      const lon = parseFloat(item.RSTR_LO);
      // 단순 유클리드 거리: 실제 지구 곡률 무시. 정확도를 원한다면 Haversine 공식을 사용.
      const d = haversineDistance(y, x, lat, lon); // 함수 아래 정의
      return d <= radius;
    });
  } else {
    return items;
  }
}

/**
 * 주변 부산푸디투어정보 조회
 * 구조와 로직은 fetchNearbyFoodService와 유사
 */
export async function fetchNearbyFoodieService(x, y, radius) {
  const url = new URL(FOODIE_SERVICE_URL);
  url.searchParams.append('ServiceKey', FOODIE_SERVICE_KEY);
  url.searchParams.append('pageNo', '1');
  url.searchParams.append('numOfRows', '1000');
  url.searchParams.append('resultType', 'json');

  const res = await fetch(url.toString());
  if (!res.ok) {
    throw new Error(`부산푸디투어정보 API 오류: ${res.status}`);
  }
  const data = await res.json();
  const items = data.response?.body?.items?.item || [];
  if (radius != null) {
    return items.filter(item => {
      if (!item.LAT || !item.LNG) return false;
      const lat = parseFloat(item.LAT);
      const lon = parseFloat(item.LNG);
      const d = haversineDistance(y, x, lat, lon);
      return d <= radius;
    });
  } else {
    return items;
  }
}

/**
 * 위도/경도 거리 계산 (미터 단위): Haversine 공식
 * lat1, lon1: 위도/경도 (십진수), lat2, lon2: 비교 대상
 */
function haversineDistance(lat1, lon1, lat2, lon2) {
  const toRad = deg => (deg * Math.PI) / 180;
  const R = 6371000; // 지구 반지름(m)
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δφ = toRad(lat2 - lat1);
  const Δλ = toRad(lon2 - lon1);
  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return d;
}
